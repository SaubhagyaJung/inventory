import React from 'react';

function Footer() {
  return <div className='mt-2'></div>;
}

export default Footer;

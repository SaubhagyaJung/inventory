
import DisplayEmployeeInfo from "../components/admin/DisplayEmployeeInfo";

function AdminEmployeeEditPage() {

    return (
        <div>
            <DisplayEmployeeInfo />
        </div>
    )
}

export default AdminEmployeeEditPage;
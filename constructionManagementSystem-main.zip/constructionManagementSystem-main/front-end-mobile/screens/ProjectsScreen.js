import { StyleSheet, Text, View } from 'react-native';
import React from "react";


function ProjectsScreen() {
    return (
        <View>
            <Text>Projects</Text>
        </View>
    )
}

export default ProjectsScreen;

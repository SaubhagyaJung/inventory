import { StyleSheet, Text, View } from 'react-native';
import React from "react";


function MyProfileScreen() {
    return (
        <View>
            <Text>My Profile</Text>
        </View>
    )
}

export default MyProfileScreen
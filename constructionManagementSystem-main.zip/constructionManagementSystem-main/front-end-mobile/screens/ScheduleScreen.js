import { StyleSheet, Text, View } from 'react-native';
import React from "react";


function ScheduleScreen() {
    return (
        <View>
            <Text>Schedule</Text>
        </View>
    )
}

export default ScheduleScreen;

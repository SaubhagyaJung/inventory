import { StyleSheet, Text, View } from 'react-native';
import React from "react";


function TasksScreen() {
    return (
        <View>
            <Text>Tasks</Text>
        </View>
    )
}

export default TasksScreen;

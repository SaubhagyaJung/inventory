import { StyleSheet, Text, View } from 'react-native';
import React from "react";


function HomeScreen() {
    return (
        <View>
            <Text>Home</Text>
        </View>
    )
}

export default HomeScreen
import React from 'react'
import { View, Text } from 'react-native'

export default function Header() {
    return (
        <View>
            <Text></Text>
        </View>
    )
}
